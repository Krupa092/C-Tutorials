#include<iostream>

int main()
{
    int a=10;
    std::cout<<"This program checks the value of a.\n";
    if (a==10)
    {
        std::cout<<"a is not equal to half dozen.\n";
    }
    std::cout<<"I only have to say only this statement.";
    return 0;
}