/*Goal: practice functions that do not return
**a value and do not accept parameters
*/

#include<iostream>
using namespace std;
void Print_Hello_World();

int main()
{
    Print_Hello_World();
    return 0;
}

void Print_Hello_World()
{
    cout<<"Hello World From Function!"; 
}