/*Goal: write a function called printMessage()
**that prints: Functions
*/

#include<iostream>
using namespace std;

void printMessage();

int main()
{
    printMessage();
    return 0;
}

void printMessage()
{
    cout<<"Functions";
}
