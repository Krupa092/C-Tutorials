#include<iostream>
#include<vector>
using namespace std;

int main()
{
    vector <int> VectorInts; 
    vector<int> :: iterator it; 

    VectorInts.push_back(0);
    VectorInts.push_back(1);
    VectorInts.push_back(2);
    VectorInts.push_back(3);
    VectorInts.push_back(4);
    VectorInts.push_back(5);
    VectorInts.push_back(6);
    VectorInts.push_back(7);

    cout<<"vector has " <<VectorInts.size() <<"elements \n";

    //Printing contents of vector ints
    cout<< "VectorInts has these elements \n";
    for(it = VectorInts.begin(); it != VectorInts.end(); ++it)
        cout<<*it <<"\n";
    //insert an element after the first element
    it = VectorInts.begin() + 1;
    VectorInts.emplace(it, -1);
    cout<<"After Insert \n";
    for(it = VectorInts.begin(); it != VectorInts.end(); ++it)
        cout<<*it<<"\n";
    //insert an element after the third element
    it  = VectorInts.begin();
    VectorInts.emplace(it + 3, -2);
    cout<<"\n\nAfter the insert\n";
    for (it = VectorInts.begin(); it != VectorInts.end(); ++it)
        cout<<*it<<"\n";

    //insert an element after the third element
     it  = VectorInts.begin();
    VectorInts.emplace(it + 5, -3);
    cout<<"\n\nAfter the insert\n";
    for (it = VectorInts.begin(); it != VectorInts.end(); ++it)
        cout<<*it<<"\n";
    
    return 0;
}
